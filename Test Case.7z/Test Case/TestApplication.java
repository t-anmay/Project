package com.capgemini.bratu.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.bratu.entities.Application;
import com.capgemini.bratu.exception.ApplicationException;
import com.capgemini.bratu.repository.ApplicationDao;
import com.capgemini.bratu.util.Status;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/jpaContext.xml")
public class TestApplication {

	@Autowired
	ApplicationDao appdao;
	
	Application application = new Application();
	@Before
	public void setUp(){
	
		application.setApplication_id(23);
		application.setCourseName("Btech");
		application.setDate_of_birth("12/12/2002");
		application.setDate_of_interview(new Date());
		application.setEmail_id("vinod41s@gmail.com");
		application.setFull_name("Vinod");
		application.setGoals("Cricket");
		application.setHighest_qualification("Graduation");
		application.setMarks_obtained(12d);
		application.setStatus("applied");
		application.setScheduled_program_id(12l);
		application.setRoll_no("12121");
	}
	
	
	@Test
	public void test() throws ApplicationException {
		Status status =appdao.save(application);
		boolean flag = false;
		if(status.getCode()==1){
			flag = true ;
		}
		assertTrue(true);
		
	}

}
