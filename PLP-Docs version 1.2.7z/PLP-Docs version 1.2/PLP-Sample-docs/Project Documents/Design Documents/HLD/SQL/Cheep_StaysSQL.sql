--drop tables and constraints

DROP TABLE user_details CASCADE CONSTRAINTS;
DROP TABLE Hotels CASCADE CONSTRAINTS;
DROP TABLE room_details CASCADE CONSTRAINTS;
DROP TABLE booking_details CASCADE CONSTRAINTS;

--drop sequences

DROP SEQUENCE userId_seq;
DROP SEQUENCE booking_seq;
DROP SEQUENCE room_seq;

--Create tables

CREATE TABLE user_details
(
      user_id NUMBER  PRIMARY KEY, 
      password VARCHAR(20) NOT NULL, 
      role VARCHAR(10) NOT NULL,
      user_name VARCHAR (20) NOT NULL,
      mobile_no VARCHAR(10) NOT NULL,
      phone VARCHAR(15) ,
      address VARCHAR(25) NOT NULL,
      email VARCHAR(25) NOT NULL
);


CREATE TABLE Hotels
(	
	hotel_id NUMBER PRIMARY KEY, 
	city VARCHAR(10) NOT NULL,
	hotel_name VARCHAR (30) NOT NULL,
	address VARCHAR(35) NOT NULL,
	description VARCHAR(50) NOT NULL,
	avg_rate_per_night NUMBER(7,2) NOT NULL,
	phone_no1 VARCHAR(10) NOT NULL,
 	phone_no2 VARCHAR(10),
 	rating VARCHAR(4) NOT NULL,
	email VARCHAR(30) NOT NULL,
	fax VARCHAR(15) NOT NULL
);

CREATE TABLE room_details
(
	hotel_id NUMBER REFERENCES Hotels(hotel_id),
	room_id NUMBER PRIMARY KEY,
	room_no VARCHAR(3) NOT NULL,
	room_type VARCHAR(30) NOT NULL,
	per_night_rate  NUMBER(8,2) NOT NULL,
	availability CHAR(1) NOT NULL
);

CREATE TABLE booking_details
(
	booking_id NUMBER(6) NOT NULL,
	room_id NUMBER NOT NULL,
	user_id NUMBER NOT NULL,
	user_name VARCHAR(20),
	booked_from DATE,
	booked_to DATE,
	amount NUMBER(9,2) NOT NULL
);


--Create sequences

CREATE SEQUENCE userId_seq START WITH 101;

CREATE SEQUENCE booking_seq START WITH 1001;

CREATE SEQUENCE room_seq START WITH 101;


--Insert statements



INSERT INTO user_details values(userId_seq.nextval,'Pass123','admin','admin','9874561230',0141-2351513,'Pune','admin@gmail.com')


INSERT INTO Hotels VALUES('1001','Pune','City View Hotel','Pimple Saudagar','Located amidst mountains',15000.00,'9856741232',
'7789564256','4','cityviewhotel@gmail.com','011235');

INSERT INTO Hotels VALUES('1002','Mumbai','Hotel Mount View','Andheri East','Located near beach',20000.00,'9856741231',
'7789564244','5','hotelmountview@gmail.com','011785');


insert into room_details values(1001 , room_seq.nextval , '501' ,'Standard non A/C room' ,12000.00 , 'Y');
insert into room_details values(1001 , room_seq.nextval , '502' ,'Standard non A/C room' ,12000.00 , 'Y');

insert into room_details values(1001 , room_seq.nextval , '601' ,'Standard A/C room' ,18000.00 , 'Y');
insert into room_details values(1001 ,room_seq.nextval , '602','Executive A/C room' ,25000.00 , 'Y');

insert into room_details values(1001 , room_seq.nextval , '701' ,'Standard A/C room' ,18000.00 , 'Y');
insert into room_details values(1001 ,room_seq.nextval , '702','Executive A/C room' ,25000.00 , 'Y');

insert into room_details values(1001 , room_seq.nextval , '801' ,'Deluxe A/C room ' ,30000.00 , 'Y');
insert into room_details values(1001 , room_seq.nextval , '802' ,'Deluxe A/C room ' ,30000.00 , 'Y');

insert into room_details values(1001 , room_seq.nextval , '901' ,'Executive A/C room' ,35000.00 , 'N');
insert into room_details values(1001 , room_seq.nextval , '902' ,'Executive A/C room ' ,35000.00 , 'N');


insert into room_details values(1002 , room_seq.nextval , '101' ,'Standard non A/C room' ,15000.00 , 'Y');
insert into room_details values(1002 , room_seq.nextval, '102' ,'Standard non A/C room' ,15000.00 , 'Y');

insert into room_details values(1002 , room_seq.nextval , '201' ,'Standard A/C room' ,22000.00 , 'Y');
insert into room_details values(1002 , room_seq.nextval , '202' ,'Standard A/C room' ,22000.00 , 'Y');

insert into room_details values(1002 ,room_seq.nextval , '301','Executive A/C room' ,30000.00 , 'Y');
insert into room_details values(1002 ,room_seq.nextval, '302','Executive A/C room' ,30000.00 , 'Y');

insert into room_details values(1002 , room_seq.nextval, '401' ,'Deluxe A/C room ' ,40000.00 , 'Y');
insert into room_details values(1002, room_seq.nextval , '402' ,'Deluxe A/C room ' ,40000.00 , 'Y');

insert into room_details values(1002 , room_seq.nextval, '403' ,'Executive A/C room' ,30000.00 , 'N');
insert into room_details values(1002, room_seq.nextval , '404' ,'Deluxe A/C room ' ,40000.00 , 'N');




INSERT INTO user_details VALUES(userId_seq.nextval,'Pass123','admin','admin','9874561230',0141-2351513,'Pune','admin@gmail.com');

insert into  booking_details values(booking_seq.nextval,111,106,'mohit','15-DEC-2016','20-DEC-2016',15000.00);

insert into  booking_details values(booking_seq.nextval,103,105,'umang','20-DEC-2016','23-DEC-2016',18000.00);

insert into  booking_details values(booking_seq.nextval,104,104,'farheen','25-DEC-2016','28-DEC-2016',25000.00);

insert into  booking_details values(booking_seq.nextval,110,103,'urvashi','25-DEC-2016','30-DEC-2016',35000.00);

insert into  booking_details values(booking_seq.nextval,107,102,'chirag','15-DEC-2016','19-DEC-2016',30000.00);

insert into  booking_details values(booking_seq.nextval,101,101,'tanmay','20-DEC-2016','24-DEC-2016',12000.00);


