--drop tables and constraints

DROP TABLE users CASCADE CONSTRAINTS;
DROP TABLE Hotels CASCADE CONSTRAINTS;
DROP TABLE roomdetails CASCADE CONSTRAINTS;
DROP TABLE bookingdetails CASCADE CONSTRAINTS;

--drop sequences

DROP SEQUENCE userId_seq;
DROP SEQUENCE booking_seq;

--Create tables

CREATE TABLE users
(
      user_id NUMBER  PRIMARY KEY, 
	  password VARCHAR(20) NOT NULL, 
      role VARCHAR(10) NOT NULL,
      user_name VARCHAR (20) NOT NULL,
      mobile_no VARCHAR(10) NOT NULL,
      phone VARCHAR(10) ,
      address VARCHAR(25) NOT NULL,
      email VARCHAR(25) NOT NULL
);


CREATE TABLE Hotels
(	
	hotel_id VARCHAR(4) PRIMARY KEY, 
	city VARCHAR(10) NOT NULL,
	hotel_name VARCHAR (30) NOT NULL,
	address VARCHAR(35) NOT NULL,
	description VARCHAR(50) NOT NULL,
	avg_rate_per_night NUMBER(7,2) NOT NULL,
	phone_no1 VARCHAR(10) NOT NULL,
 	phone_no2 VARCHAR(10),
 	rating VARCHAR(4) NOT NULL,
	email VARCHAR(30) NOT NULL,
	fax VARCHAR(15) NOT NULL
);

CREATE TABLE roomdetails
(
	hotel_id VARCHAR(4) REFERENCES Hotels(hotel_id),
	room_id VARCHAR(4) PRIMARY KEY,
	room_no VARCHAR(3) NOT NULL,
	room_type VARCHAR(30) NOT NULL,
	per_night_rate  NUMBER(8,2) NOT NULL,
	availability CHAR(1) NOT NULL
);

CREATE TABLE bookingdetails
(
	booking_id NUMBER(6) NOT NULL,
	room_id VARCHAR(4) NOT NULL,
	user_id NUMBER NOT NULL,
	booked_from DATE,
	booked_to DATE,
	amount NUMBER(9,2) NOT NULL
);


--Create sequences

CREATE SEQUENCE userId_seq START WITH 101;

CREATE SEQUENCE booking_seq START WITH 1001;


--Insert statements

INSERT INTO Hotels VALUES('1001','Pune','City View Hotel','Pimple Saudagar','Located amidst mountains',15000.00,'9856741232',
'7789564256','4','cityviewhotel@gmail.com','011235');
INSERT INTO Hotels VALUES('1002','Mumbai','Hotel Mount View','Andheri East','Located near beach',20000.00,'9856741231',
'7789564244','5','hotelmountview@gmail.com','011785');


INSERT INTO roomdetails VALUES('1001' , 'SNA1' , '501' ,'Standard non A/C room' ,12000.00 , 'Y');
INSERT INTO roomdetails VALUES('1001' , 'SNA1' , '502' ,'Standard non A/C room' ,12000.00 , 'Y');

INSERT INTO roomdetails VALUES('1001' , 'SA1' , '601' ,'Standard A/C room' ,18000.00 , 'Y');
INSERT INTO roomdetails VALUES('1001' ,'EXE1' , '602','Executive A/C room' ,25000.00 , 'Y');

INSERT INTO roomdetails VALUES('1001' , 'SA1' , '701' ,'Standard A/C room' ,18000.00 , 'Y');
INSERT INTO roomdetails VALUES('1001' ,'EXE1' , '702','Executive A/C room' ,25000.00 , 'Y');

INSERT INTO roomdetails VALUES('1001' , 'DEX1' , '801' ,'Deluxe A/C room ' ,30000.00 , 'Y');
INSERT INTO roomdetails VALUES('1001' , 'DEX1' , '802' ,'Deluxe A/C room ' ,30000.00 , 'Y');

INSERT INTO roomdetails VALUES('1002' , 'SNA2' , '101' ,'Standard non A/C room' ,15000.00 , 'Y');
INSERT INTO roomdetails VALUES('1002' , 'SNA2' , '102' ,'Standard non A/C room' ,15000.00 , 'Y');

INSERT INTO roomdetails VALUES('1002' , 'SA2' , '201' ,'Standard A/C room' ,22000.00 , 'Y');
INSERT INTO roomdetails VALUES('1002' , 'SA2' , '202' ,'Standard A/C room' ,22000.00 , 'Y');

INSERT INTO roomdetails VALUES('1002' ,'EXE2' , '301','Executive A/C room' ,30000.00 , 'Y');
INSERT INTO roomdetails VALUES('1002' ,'EXE2' , '302','Executive A/C room' ,30000.00 , 'Y');

INSERT INTO roomdetails VALUES('1002' , 'DEX2' , '401' ,'Deluxe A/C room ' ,40000.00 , 'Y');
INSERT INTO roomdetails VALUES('1002' , 'DEX2' , '402' ,'Deluxe A/C room ' ,40000.00 , 'Y');
  